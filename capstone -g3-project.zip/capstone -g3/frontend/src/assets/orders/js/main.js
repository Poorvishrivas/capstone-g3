(function($) {

	"use strict";

	$('[data-toggle="tooltip"]').tooltip()

})(jQuery);
